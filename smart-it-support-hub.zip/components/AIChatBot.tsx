
import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, Trash2 } from 'lucide-react';
import { getGeminiChatResponse } from '../services/gemini';
import { ChatMessage } from '../types';

export const AIChatBot: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'assistant', content: 'สวัสดีครับ! ผมคือ AI Smart Support ยินดีให้ความช่วยเหลือครับ วันนี้คุณมีปัญหาด้าน IT อะไรให้ผมช่วยไหมครับ?', timestamp: new Date() }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const history = messages.map(m => ({ role: m.role, content: m.content }));
      const response = await getGeminiChatResponse(history, input);
      
      const botMessage: ChatMessage = {
        role: 'assistant',
        content: response || 'ขออภัยครับ เกิดข้อผิดพลาดในการประมวลผล กรุณาลองใหม่อีกครั้ง',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      console.error('Chat error:', error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'ขออภัยครับ มีปัญหาการเชื่อมต่อกับระบบ AI กรุณาลองใหม่อีกครั้งในภายหลัง',
        timestamp: new Date()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const clearChat = () => {
    setMessages([{ 
      role: 'assistant', 
      content: 'สวัสดีครับ! ผมคือ AI Smart Support ยินดีให้ความช่วยเหลือครับ วันนี้คุณมีปัญหาด้าน IT อะไรให้ผมช่วยไหมครับ?', 
      timestamp: new Date() 
    }]);
  };

  return (
    <div className="h-[calc(100vh-10rem)] flex flex-col bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden relative">
      {/* Header */}
      <div className="bg-slate-900 p-6 flex items-center justify-between text-white">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center relative">
            <Bot size={28} />
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-slate-900"></div>
          </div>
          <div>
            <h3 className="font-bold text-lg leading-tight">AI Smart Support</h3>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-emerald-500 rounded-full"></span>
              <span className="text-[10px] uppercase tracking-widest text-emerald-400 font-bold">Online Now</span>
            </div>
          </div>
        </div>
        <button 
          onClick={clearChat}
          className="p-2 text-slate-400 hover:text-white transition-all hover:bg-slate-800 rounded-lg"
          title="ล้างการสนทนา"
        >
          <Trash2 size={20} />
        </button>
      </div>

      {/* Message Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50/50">
        {messages.map((msg, idx) => (
          <div 
            key={idx} 
            className={`flex items-start gap-3 animate-in fade-in slide-in-from-bottom-2 ${
              msg.role === 'user' ? 'flex-row-reverse' : ''
            }`}
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 shadow-sm ${
              msg.role === 'user' ? 'bg-blue-600 text-white' : 'bg-slate-900 text-white'
            }`}>
              {msg.role === 'user' ? <User size={16} /> : <Bot size={16} />}
            </div>
            
            <div className={`max-w-[80%] space-y-1`}>
              <div className={`p-4 rounded-2xl shadow-sm text-sm leading-relaxed ${
                msg.role === 'user' 
                  ? 'bg-blue-600 text-white rounded-tr-none' 
                  : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none whitespace-pre-wrap'
              }`}>
                {msg.content}
              </div>
              <p className={`text-[10px] text-slate-400 px-1 ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center shadow-sm">
              <Bot size={16} />
            </div>
            <div className="bg-white border border-slate-200 p-4 rounded-2xl rounded-tl-none shadow-sm flex items-center gap-2">
              <div className="flex gap-1">
                <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></div>
                <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]"></div>
              </div>
              <span className="text-xs text-slate-400 font-medium">Smart Support กำลังพิมพ์...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-6 bg-white border-t border-slate-200">
        <div className="mb-4 flex flex-wrap gap-2">
          {['ต่อ WiFi ไม่ได้', 'ลืมรหัสผ่าน', 'ลง Photoshop', 'อินเทอร์เน็ตช้า'].map((tag) => (
            <button 
              key={tag}
              onClick={() => {
                setInput(tag);
                // Automated trigger could be added here
              }}
              className="text-[10px] px-3 py-1 bg-slate-100 text-slate-600 rounded-full hover:bg-blue-50 hover:text-blue-600 transition-all font-semibold"
            >
              {tag}
            </button>
          ))}
        </div>
        <form onSubmit={handleSend} className="relative">
          <input 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isLoading}
            type="text" 
            placeholder="พิมพ์ปัญหาของคุณที่นี่..."
            className="w-full bg-slate-100 border-none rounded-2xl py-4 pl-5 pr-14 text-sm focus:ring-2 focus:ring-blue-500 outline-none transition-all"
          />
          <button 
            type="submit"
            disabled={!input.trim() || isLoading}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 bg-blue-600 text-white rounded-xl flex items-center justify-center hover:bg-blue-700 transition-all disabled:bg-slate-300 shadow-lg shadow-blue-500/20"
          >
            <Send size={18} />
          </button>
        </form>
        <div className="mt-3 flex items-center justify-center gap-2 text-[10px] text-slate-400 uppercase tracking-widest font-bold">
          <Sparkles size={12} className="text-blue-400" /> Powered by Gemini Flash AI
        </div>
      </div>
    </div>
  );
};
