
import React from 'react';
import { Book, FileText, ChevronRight, Hash, Star } from 'lucide-react';

const categories = [
  { name: 'Hardware Basics', count: 12, icon: '🖥️' },
  { name: 'Software Guides', count: 24, icon: '💾' },
  { name: 'Network & Connectivity', count: 8, icon: '🌐' },
  { name: 'Email & Account', count: 15, icon: '✉️' },
  { name: 'Security Tips', count: 10, icon: '🛡️' },
  { name: 'Office 365', count: 18, icon: '🏢' },
];

const topArticles = [
  { id: '1', title: 'วิธีการเชื่อมต่อ VPN จากที่บ้าน', views: 2405 },
  { id: '2', title: 'การเปลี่ยนรหัสผ่านอีเมลบริษัท', views: 1890 },
  { id: '3', title: 'วิธีแก้ไขเบื้องต้นเมื่อ WiFi หลุดบ่อย', views: 1560 },
  { id: '4', title: 'คู่มือการติดตั้ง Printer ส่วนกลาง', views: 1240 },
];

export const KnowledgeBase: React.FC = () => {
  return (
    <div className="space-y-8">
      <div className="bg-blue-600 rounded-3xl p-12 text-center text-white relative overflow-hidden shadow-2xl shadow-blue-500/20">
        {/* Background blobs */}
        <div className="absolute top-0 left-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-400/20 rounded-full blur-3xl translate-x-1/2 translate-y-1/2"></div>
        
        <h1 className="text-4xl font-extrabold mb-4 relative z-10">ค้นหาคำตอบด้วยตัวคุณเอง</h1>
        <p className="text-blue-100 mb-8 max-w-lg mx-auto relative z-10">คลังความรู้ที่รวมวิธีการแก้ไขปัญหา IT เบื้องต้นให้คุณจัดการได้ทันที</p>
        
        <div className="max-w-xl mx-auto relative z-10">
          <input 
            type="text" 
            placeholder="เช่น 'WiFi', 'เปลี่ยนรหัสผ่าน', 'ลงโปรแกรม'..."
            className="w-full bg-white text-slate-900 rounded-2xl py-5 px-6 shadow-xl outline-none focus:ring-4 focus:ring-blue-300 transition-all text-lg font-medium"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map((cat) => (
          <div key={cat.name} className="bg-white p-6 rounded-3xl border border-slate-200 hover:border-blue-400 hover:shadow-lg transition-all group cursor-pointer">
            <div className="text-4xl mb-4 grayscale group-hover:grayscale-0 transition-all">{cat.icon}</div>
            <h3 className="font-bold text-slate-900 group-hover:text-blue-600 transition-colors">{cat.name}</h3>
            <p className="text-xs text-slate-500 mt-1">{cat.count} บทความ</p>
            <div className="mt-4 flex items-center text-blue-600 text-xs font-bold opacity-0 group-hover:opacity-100 transition-all">
              ดูทั้งหมด <ChevronRight size={14} />
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <Star className="text-amber-400 fill-amber-400" size={20} />
            <h4 className="font-bold text-slate-900">บทความยอดนิยม</h4>
          </div>
          <div className="space-y-3">
            {topArticles.map((article) => (
              <div key={article.id} className="bg-white p-4 rounded-2xl border border-slate-100 flex items-center justify-between hover:bg-slate-50 transition-all cursor-pointer group">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-400 group-hover:bg-blue-100 group-hover:text-blue-600 transition-all">
                    <FileText size={20} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{article.title}</p>
                    <p className="text-[10px] text-slate-400 uppercase tracking-widest">{article.views} VIEWS</p>
                  </div>
                </div>
                <ChevronRight size={18} className="text-slate-300 group-hover:text-blue-600 transition-all" />
              </div>
            ))}
          </div>
        </div>

        <div className="bg-slate-900 rounded-3xl p-8 text-white relative overflow-hidden">
          <Hash className="absolute top-4 right-4 text-white/10" size={120} />
          <h4 className="text-xl font-bold mb-4 relative z-10">แท็กยอดฮิต</h4>
          <div className="flex flex-wrap gap-2 relative z-10">
            {['#WiFi', '#Password', '#VPN', '#Printer', '#Security', '#Hardware', '#Outlook', '#MacBook', '#Windows11', '#Teams'].map((tag) => (
              <span key={tag} className="px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-xs font-medium transition-all cursor-pointer">
                {tag}
              </span>
            ))}
          </div>
          <div className="mt-12 relative z-10">
            <p className="text-slate-400 text-sm">ไม่พบสิ่งที่คุณกำลังหาใช่ไหม?</p>
            <button className="mt-4 bg-white text-slate-900 px-6 py-2.5 rounded-xl font-bold text-sm hover:bg-slate-200 transition-all">
              แชทถาม AI Support
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
