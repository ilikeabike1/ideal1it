
import React from 'react';
import { TicketStatus, TicketPriority, Ticket } from '../types';
import { Filter, MoreHorizontal, ChevronRight } from 'lucide-react';

// Added missing description property to each mock ticket to satisfy the Ticket interface requirement
const mockTickets: Ticket[] = [
  { id: 'TIC-001', title: 'หน้าจอไม่ติด (Monitor flickering)', description: 'หน้าจอติดๆ ดับๆ ตลอดเวลาที่เริ่มใช้งาน', status: TicketStatus.IN_PROGRESS, priority: TicketPriority.HIGH, category: 'Hardware', createdAt: '2024-03-20 09:00', requester: 'Somchai D.' },
  { id: 'TIC-002', title: 'ลืมรหัสผ่าน Email', description: 'ไม่สามารถจำรหัสผ่านของ Outlook ได้ ต้องการรีเซ็ต', status: TicketStatus.OPEN, priority: TicketPriority.MEDIUM, category: 'Account', createdAt: '2024-03-20 10:15', requester: 'Jane S.' },
  { id: 'TIC-003', title: 'อินเทอร์เน็ตใช้งานไม่ได้ (No Internet)', description: 'ไม่สามารถเชื่อมต่อ WiFi ของบริษัทได้ ขึ้น No Internet Access', status: TicketStatus.RESOLVED, priority: TicketPriority.CRITICAL, category: 'Network', createdAt: '2024-03-19 14:20', requester: 'Tech It.' },
  { id: 'TIC-004', title: 'ติดตั้งโปรแกรม Photoshop', description: 'ต้องการติดตั้ง Photoshop 2024 สำหรับงานกราฟิก', status: TicketStatus.CLOSED, priority: TicketPriority.LOW, category: 'Software', createdAt: '2024-03-19 11:00', requester: 'Artist B.' },
  { id: 'TIC-005', title: 'เครื่องช้ามาก (Laptop lagging)', description: 'เครื่องช้ามากเมื่อเปิดโปรแกรมหลายตัวพร้อมกัน', status: TicketStatus.OPEN, priority: TicketPriority.LOW, category: 'Hardware', createdAt: '2024-03-20 11:30', requester: 'David K.' },
];

const StatusBadge = ({ status }: { status: TicketStatus }) => {
  const styles = {
    [TicketStatus.OPEN]: 'bg-blue-100 text-blue-700',
    [TicketStatus.IN_PROGRESS]: 'bg-amber-100 text-amber-700',
    [TicketStatus.RESOLVED]: 'bg-emerald-100 text-emerald-700',
    [TicketStatus.CLOSED]: 'bg-slate-100 text-slate-700',
  };
  return <span className={`px-2 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider ${styles[status]}`}>{status}</span>;
};

const PriorityIndicator = ({ priority }: { priority: TicketPriority }) => {
  const styles = {
    [TicketPriority.LOW]: 'bg-slate-200',
    [TicketPriority.MEDIUM]: 'bg-blue-400',
    [TicketPriority.HIGH]: 'bg-orange-500',
    [TicketPriority.CRITICAL]: 'bg-rose-600 animate-pulse',
  };
  return (
    <div className="flex items-center gap-2">
      <div className={`w-2 h-2 rounded-full ${styles[priority]}`}></div>
      <span className="text-xs text-slate-600">{priority}</span>
    </div>
  );
};

export const TicketList: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-slate-900">รายการแจ้งซ่อม (Tickets)</h1>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 border border-slate-200 bg-white rounded-xl text-sm font-medium hover:bg-slate-50 transition-all">
            <Filter size={16} /> กรองข้อมูล
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 text-xs font-bold uppercase tracking-wider">
            <tr>
              <th className="px-6 py-4">ID / ผู้แจ้ง</th>
              <th className="px-6 py-4">หัวข้อ / หมวดหมู่</th>
              <th className="px-6 py-4">ความสำคัญ</th>
              <th className="px-6 py-4">สถานะ</th>
              <th className="px-6 py-4">วันที่แจ้ง</th>
              <th className="px-6 py-4"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {mockTickets.map((ticket) => (
              <tr key={ticket.id} className="hover:bg-slate-50 transition-colors cursor-pointer group">
                <td className="px-6 py-4">
                  <div className="flex flex-col">
                    <span className="text-xs font-bold text-blue-600">{ticket.id}</span>
                    <span className="text-sm font-medium text-slate-900">{ticket.requester}</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex flex-col">
                    <span className="text-sm font-semibold text-slate-900">{ticket.title}</span>
                    <span className="text-xs text-slate-500">{ticket.category}</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <PriorityIndicator priority={ticket.priority} />
                </td>
                <td className="px-6 py-4">
                  <StatusBadge status={ticket.status} />
                </td>
                <td className="px-6 py-4 text-xs text-slate-500">
                  {ticket.createdAt}
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="p-2 text-slate-400 hover:text-blue-600">
                      <ChevronRight size={20} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
