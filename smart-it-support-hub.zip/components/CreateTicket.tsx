
import React, { useState } from 'react';
import { TicketPriority } from '../types';
import { Send, Upload, Info } from 'lucide-react';

interface CreateTicketProps {
  onSuccess: () => void;
}

export const CreateTicket: React.FC<CreateTicketProps> = ({ onSuccess }) => {
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      onSuccess();
    }, 1500);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-bold text-slate-900">แจ้งปัญหาใหม่</h1>
        <div className="bg-blue-100 text-blue-600 px-2 py-0.5 rounded text-[10px] font-bold uppercase">New Case</div>
      </div>

      <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">หัวข้อปัญหา <span className="text-red-500">*</span></label>
              <input 
                required
                type="text" 
                placeholder="เช่น ไม่สามารถต่อ WiFi ได้"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">หมวดหมู่</label>
              <select className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all">
                <option>Hardware (อุปกรณ์พัง)</option>
                <option>Software (โปรแกรม)</option>
                <option>Network (เครือข่าย/อินเทอร์เน็ต)</option>
                <option>Account (บัญชีผู้ใช้/รหัสผ่าน)</option>
                <option>Other (อื่นๆ)</option>
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">ระดับความสำคัญ</label>
            <div className="flex flex-wrap gap-3">
              {[TicketPriority.LOW, TicketPriority.MEDIUM, TicketPriority.HIGH, TicketPriority.CRITICAL].map((p) => (
                <label key={p} className="flex-1 min-w-[100px] cursor-pointer group">
                  <input type="radio" name="priority" className="peer hidden" defaultChecked={p === TicketPriority.MEDIUM} />
                  <div className="text-center px-4 py-3 rounded-xl border border-slate-200 peer-checked:border-blue-500 peer-checked:bg-blue-50 peer-checked:text-blue-700 transition-all text-sm font-medium text-slate-500 group-hover:border-slate-300">
                    {p}
                  </div>
                </label>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">รายละเอียดเพิ่มเติม</label>
            <textarea 
              rows={5}
              placeholder="กรุณาระบุรายละเอียด เช่น รุ่นอุปกรณ์, ขั้นตอนการเกิดปัญหา..."
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all resize-none"
            ></textarea>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">แนบรูปภาพหรือไฟล์ประกอบ</label>
            <div className="border-2 border-dashed border-slate-200 rounded-2xl p-8 text-center hover:border-blue-400 hover:bg-blue-50 transition-all cursor-pointer">
              <Upload className="mx-auto text-slate-400 mb-3" size={32} />
              <p className="text-sm text-slate-500">ลากไฟล์มาวางที่นี่ หรือ <span className="text-blue-600 font-bold">เลือกไฟล์จากคอมพิวเตอร์</span></p>
              <p className="text-xs text-slate-400 mt-1">ไฟล์ JPG, PNG, PDF ขนาดไม่เกิน 5MB</p>
            </div>
          </div>

          <div className="bg-slate-50 p-4 rounded-xl flex gap-3 items-start border border-slate-100">
            <Info className="text-slate-400 shrink-0 mt-0.5" size={18} />
            <p className="text-xs text-slate-500 leading-relaxed">ข้อมูลของคุณจะถูกเก็บเป็นความลับและถูกส่งไปยังทีม IT Support ทันที เราจะพยายามติดต่อกลับภายใน 4-8 ชั่วโมงทำการ</p>
          </div>

          <button 
            disabled={loading}
            className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 disabled:bg-slate-300 disabled:shadow-none"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <>
                <Send size={20} />
                ยืนยันการแจ้งปัญหา
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
