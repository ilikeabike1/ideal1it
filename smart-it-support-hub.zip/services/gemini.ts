
import { GoogleGenAI } from "@google/genai";

const SYSTEM_INSTRUCTION = `คุณคือผู้ช่วย IT Support อัจฉริยะ (AI Smart Support) ที่เชี่ยวชาญด้านเทคนิค
หน้าที่ของคุณคือ:
1. ช่วยผู้ใช้แก้ปัญหา IT เบื้องต้น เช่น ลืมรหัสผ่าน, อินเทอร์เน็ตหลุด, ลงโปรแกรมไม่ได้, อุปกรณ์มีปัญหา
2. ให้คำแนะนำที่ชัดเจน เป็นลำดับขั้นตอน (Step-by-step)
3. สื่อสารอย่างมืออาชีพ สุภาพ และเข้าใจง่าย
4. หากปัญหาดูเหมือนจะเป็นเรื่องใหญ่ (เช่น Server ล่ม หรืออุปกรณ์พังเสียหายหนัก) ให้แนะนำให้ผู้ใช้ 'เปิดตั๋วใหม่' (Open Ticket) ในเมนูแจ้งซ่อม
5. ตอบเป็นภาษาไทยเป็นหลัก เว้นแต่ผู้ใช้จะถามเป็นภาษาอังกฤษ

Context ข้อมูลเบื้องต้น:
- เวลาทำการ IT: จันทร์-ศุกร์ 08:30 - 17:30
- เบอร์ติดต่อด่วน: 02-XXX-XXXX
- สถานที่รับซ่อม: อาคาร A ชั้น 5`;

export const getGeminiChatResponse = async (history: {role: string, content: string}[], message: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const contents = history.map(h => ({
    role: h.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: h.content }]
  }));

  // Add the current message
  contents.push({
    role: 'user',
    parts: [{ text: message }]
  });

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: contents,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      temperature: 0.7,
      topP: 0.8,
      maxOutputTokens: 1024,
    }
  });

  return response.text;
};
